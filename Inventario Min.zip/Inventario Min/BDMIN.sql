/*
SQLyog Ultimate v9.02 
MySQL - 5.6.12-log : Database - inventario_min
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`inventario_min` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `inventario_min`;

/*Table structure for table `auditoria` */

DROP TABLE IF EXISTS `auditoria`;

CREATE TABLE `auditoria` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `login` varchar(20) DEFAULT NULL,
  `operacion` varchar(20) DEFAULT NULL,
  `tabla` varchar(20) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=589 DEFAULT CHARSET=latin1;

/*Data for the table `auditoria` */

insert  into `auditoria`(`id`,`login`,`operacion`,`tabla`,`descripcion`,`fecha`,`hora`) values (311,'administrador','ACCESO','Sistema','acceso al sistema usuario administrador','2014-06-24','22:54:44'),(312,'administrador','REGISTRO','proveedores','codigo:  01','2014-06-24','22:55:41'),(313,'administrador','REGISTRO','productos','codigo:  01','2014-06-24','22:56:04'),(314,'administrador','REGISTRO','productos','codigo:  02','2014-06-24','22:56:25'),(315,'administrador','REGISTRO','productos','codigo:  03','2014-06-24','22:56:32'),(316,'administrador','REGISTRO','insumos','codigo:  1','2014-06-24','22:56:45'),(317,'administrador','SALIDA','Sistema','salida del sistema usuario administrador','2014-06-24','22:56:54'),(318,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','22:59:00'),(319,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:00:30'),(320,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:01:04'),(321,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:11:52'),(322,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:14:05'),(323,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:14:33'),(324,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:14:38'),(325,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:15:37'),(326,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:15:47'),(327,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:16:41'),(328,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:16:49'),(329,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:18:45'),(330,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:18:58'),(331,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:19:53'),(332,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:20:12'),(333,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:21:09'),(334,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:21:54'),(335,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:22:03'),(336,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:23:44'),(337,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:24:05'),(338,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:24:24'),(339,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:24:27'),(340,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:30:49'),(341,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:31:00'),(342,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:35:09'),(343,'1','REGISTRO','clientes','codigo:  01','2014-06-24','23:35:36'),(344,'1','REGISTRO','clientes','codigo:  02','2014-06-24','23:35:48'),(345,'1','REGISTRO','clientes','codigo:  03','2014-06-24','23:35:59'),(346,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:36:47'),(347,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:37:12'),(348,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:42:58'),(349,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:45:17'),(350,'1','REGISTRO','insumos','codigo:  2','2014-06-24','23:46:03'),(351,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:46:12'),(352,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:52:12'),(353,'1','REGISTRO','facturas','codigo:  1','2014-06-24','23:52:24'),(354,'1','ACTUALIZAR','facturas','codigo:  1','2014-06-24','23:52:26'),(355,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:55:12'),(356,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:55:55'),(357,'1','REGISTRO','facturas','codigo:  1','2014-06-24','23:56:22'),(358,'1','ACTUALIZAR','facturas','codigo:  1','2014-06-24','23:56:32'),(359,'1','REGISTRO','carga_inventario','Número:  1','2014-06-24','23:57:12'),(360,'1','REGISTRO','facturas','codigo:  1','2014-06-24','23:57:25'),(361,'1','ACTUALIZAR','facturas','codigo:  1','2014-06-24','23:57:30'),(362,'1','REGISTRO','facturas','codigo:  2','2014-06-24','23:57:52'),(363,'1','ACTUALIZAR','facturas','codigo:  2','2014-06-24','23:57:54'),(364,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-24','23:58:07'),(365,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-24','23:58:36'),(366,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:00:06'),(367,'1','REGISTRO','facturas','codigo:  3','2014-06-25','00:00:14'),(368,'1','ACTUALIZAR','facturas','codigo:  3','2014-06-25','00:00:17'),(369,'1','ACTUALIZAR','facturas','codigo:  3','2014-06-25','00:00:23'),(370,'1','ACTUALIZAR','facturas','codigo:  3','2014-06-25','00:00:24'),(371,'1','ACTUALIZAR','facturas','codigo:  3','2014-06-25','00:00:26'),(372,'1','ACTUALIZAR','facturas','codigo:  3','2014-06-25','00:00:36'),(373,'1','ACTUALIZAR','facturas','codigo:  3','2014-06-25','00:00:37'),(374,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:02:27'),(375,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:02:35'),(376,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:07:22'),(377,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:09:31'),(378,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:09:47'),(379,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:11:11'),(380,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:11:22'),(381,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:12:15'),(382,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:12:36'),(383,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:13:59'),(384,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:14:06'),(385,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:14:14'),(386,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:14:29'),(387,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:19:53'),(388,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:20:09'),(389,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:24:25'),(390,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:24:36'),(391,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:24:56'),(392,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:25:44'),(393,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:27:14'),(394,'1','REGISTRO','facturas','codigo:  4','2014-06-25','00:27:21'),(395,'1','ACTUALIZAR','facturas','codigo:  4','2014-06-25','00:27:26'),(396,'1','ACTUALIZAR','facturas','codigo:  4','2014-06-25','00:27:32'),(397,'1','ACTUALIZAR','facturas','codigo:  4','2014-06-25','00:27:34'),(398,'1','REGISTRO','carga_inventario','Número:  2','2014-06-25','00:27:56'),(399,'1','REGISTRO','facturas','codigo:  5','2014-06-25','00:28:11'),(400,'1','ACTUALIZAR','facturas','codigo:  5','2014-06-25','00:28:14'),(401,'1','ACTUALIZAR','facturas','codigo:  5','2014-06-25','00:28:16'),(402,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:28:43'),(403,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:31:59'),(404,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:34:15'),(405,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:35:42'),(406,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:37:45'),(407,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:38:03'),(408,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:38:23'),(409,'1','REGISTRO','carga_inventario','Número:  3','2014-06-25','00:39:04'),(410,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:39:26'),(411,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:43:03'),(412,'1','ACTUALIZAR','proveedores','codigo:  01','2014-06-25','00:46:21'),(413,'1','REGISTRO','proveedores','codigo:  02','2014-06-25','00:46:44'),(414,'1','REGISTRO','proveedores','codigo:  03','2014-06-25','00:47:15'),(415,'1','REGISTRO','facturas','codigo:  6','2014-06-25','00:48:13'),(416,'1','ACTUALIZAR','facturas','codigo:  6','2014-06-25','00:48:17'),(417,'1','ACTUALIZAR','facturas','codigo:  6','2014-06-25','00:48:23'),(418,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:48:40'),(419,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:49:05'),(420,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:49:14'),(421,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:49:21'),(422,'1','REGISTRO','facturas','codigo:  6','2014-06-25','00:49:32'),(423,'1','ACTUALIZAR','facturas','codigo:  6','2014-06-25','00:49:35'),(424,'1','ACTUALIZAR','facturas','codigo:  6','2014-06-25','00:49:40'),(425,'1','ACTUALIZAR','facturas','codigo:  6','2014-06-25','00:49:45'),(426,'1','ACTUALIZAR','facturas','codigo:  6','2014-06-25','00:49:47'),(427,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:50:40'),(428,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:50:47'),(429,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','00:51:08'),(430,'01','ACCESO','Sistema','acceso al sistema usuario 01','2014-06-25','00:51:14'),(431,'01','REGISTRO','carga_inventario','Número:  4','2014-06-25','00:51:36'),(432,'01','ACTUALIZAR','proveedores','codigo:  01','2014-06-25','00:53:06'),(433,'01','ACTUALIZAR','clientes','codigo:  02','2014-06-25','00:55:54'),(434,'01','SALIDA','Sistema','salida del sistema usuario 01','2014-06-25','00:57:55'),(435,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','00:59:15'),(436,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','01:00:31'),(437,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','01:01:34'),(438,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','01:03:28'),(439,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','01:07:27'),(440,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','01:08:01'),(441,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:33:40'),(442,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:37:42'),(443,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','02:38:38'),(444,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:39:07'),(445,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:41:02'),(446,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','02:41:17'),(447,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:41:50'),(448,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','02:42:00'),(449,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:44:27'),(450,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:46:40'),(451,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:47:15'),(452,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','02:47:34'),(453,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:49:13'),(454,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:52:57'),(455,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','02:53:10'),(456,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:54:43'),(457,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','02:54:59'),(458,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:55:17'),(459,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','02:59:40'),(460,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','02:59:53'),(461,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:00:34'),(462,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:02:03'),(463,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:06:52'),(464,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:12:30'),(465,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','03:12:45'),(466,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:13:07'),(467,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:18:51'),(468,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','03:19:01'),(469,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:31:39'),(470,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','03:31:48'),(471,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:32:21'),(472,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','03:32:36'),(473,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:33:11'),(474,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','03:33:19'),(475,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:38:13'),(476,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','03:38:21'),(477,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:39:03'),(478,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','03:39:14'),(479,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:39:46'),(480,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','03:39:53'),(481,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:43:29'),(482,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','03:43:42'),(483,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:44:31'),(484,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','03:44:53'),(485,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','03:50:00'),(486,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','20:42:16'),(487,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','20:49:55'),(488,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','20:51:40'),(489,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','20:52:11'),(490,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','20:54:22'),(491,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','20:55:16'),(492,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','20:56:34'),(493,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','20:56:44'),(494,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','21:11:28'),(495,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','21:11:56'),(496,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','21:12:12'),(497,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','21:13:04'),(498,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','21:13:21'),(499,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','21:16:50'),(500,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','21:17:10'),(501,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','21:17:52'),(502,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','21:19:17'),(503,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','21:26:16'),(504,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','21:28:28'),(505,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:06:01'),(506,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:07:24'),(507,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','23:08:07'),(508,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:09:06'),(509,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','23:12:33'),(510,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:17:18'),(511,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','23:17:38'),(512,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:19:10'),(513,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:19:51'),(514,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','23:20:32'),(515,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:20:40'),(516,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','23:20:50'),(517,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:26:38'),(518,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','23:26:54'),(519,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:28:49'),(520,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','23:29:28'),(521,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:31:20'),(522,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','23:32:28'),(523,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:37:18'),(524,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:39:23'),(525,'1','REGISTRO','carga_inventario','Número:  5','2014-06-25','23:39:57'),(526,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:42:50'),(527,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:47:38'),(528,'1','REGISTRO','carga_inventario','Número:  6','2014-06-25','23:47:52'),(529,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:52:15'),(530,'1','REGISTRO','carga_inventario','Número:  7','2014-06-25','23:57:25'),(531,'1','REGISTRO','carga_inventario','Número:  8','2014-06-25','23:57:53'),(532,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','23:58:02'),(533,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-25','23:58:10'),(534,'1','REGISTRO','carga_inventario','Número:  9','2014-06-25','23:58:53'),(535,'1','REGISTRO','carga_inventario','Número:  10','2014-06-25','23:59:23'),(536,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-25','23:59:34'),(537,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','00:16:02'),(538,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','00:16:38'),(539,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','00:19:01'),(540,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','01:12:48'),(541,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:00:04'),(542,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:00:37'),(543,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:01:18'),(544,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:01:27'),(545,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:17:29'),(546,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:17:43'),(547,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:26:17'),(548,'1','REGISTRO','facturas','codigo:  6','2014-06-26','02:26:25'),(549,'1','ACTUALIZAR','facturas','codigo:  6','2014-06-26','02:26:27'),(550,'1','ACTUALIZAR','facturas','codigo:  6','2014-06-26','02:26:31'),(551,'1','ACTUALIZAR','facturas','codigo:  6','2014-06-26','02:26:33'),(552,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:26:40'),(553,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:26:47'),(554,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:27:10'),(555,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:27:43'),(556,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:27:51'),(557,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:28:16'),(558,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:28:36'),(559,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:30:08'),(560,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:30:18'),(561,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:31:19'),(562,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:31:42'),(563,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:34:02'),(564,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:34:07'),(565,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:35:05'),(566,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:35:34'),(567,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:40:19'),(568,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:40:33'),(569,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:43:40'),(570,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:44:58'),(571,'1','REGISTRO','facturas','codigo:  7','2014-06-26','02:45:05'),(572,'1','ACTUALIZAR','facturas','codigo:  7','2014-06-26','02:45:08'),(573,'1','ACTUALIZAR','facturas','codigo:  7','2014-06-26','02:45:12'),(574,'1','ACTUALIZAR','facturas','codigo:  7','2014-06-26','02:45:14'),(575,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','02:45:22'),(576,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:45:40'),(577,'1','REGISTRO','carga_inventario','Número:  11','2014-06-26','02:45:47'),(578,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-06-26','02:47:54'),(579,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-06-26','03:10:44'),(580,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-07-02','12:23:36'),(581,'1','REGISTRO','productos','codigo:  01','2014-07-02','12:24:01'),(582,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-07-02','12:24:23'),(583,'1','ACCESO','Sistema','acceso al sistema usuario 1','2014-07-02','12:25:47'),(584,'1','ACTUALIZAR','productos','codigo:  01','2014-07-02','12:25:59'),(585,'1','ELIMINAR','productos','codigo:  01','2014-07-02','12:26:04'),(586,'1','REGISTRO','productos','codigo:  01','2014-07-02','12:26:11'),(587,'1','ACTUALIZAR','productos','codigo:  01','2014-07-02','12:26:18'),(588,'1','SALIDA','Sistema','salida del sistema usuario 1','2014-07-02','12:26:22');

/*Table structure for table `carga_inventario` */

DROP TABLE IF EXISTS `carga_inventario`;

CREATE TABLE `carga_inventario` (
  `nro_carga` bigint(20) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `responsable` varchar(100) DEFAULT NULL,
  `tipo` varchar(3) DEFAULT NULL,
  `observacion` varchar(200) DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`nro_carga`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `carga_inventario` */

/*Table structure for table `carga_productos` */

DROP TABLE IF EXISTS `carga_productos`;

CREATE TABLE `carga_productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nro_carga` bigint(20) NOT NULL,
  `codigo_producto` varchar(15) NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `codigo_producto` (`codigo_producto`),
  KEY `nro_carga` (`nro_carga`),
  CONSTRAINT `carga_productos_ibfk_1` FOREIGN KEY (`codigo_producto`) REFERENCES `productos` (`codigo_producto`) ON UPDATE CASCADE,
  CONSTRAINT `carga_productos_ibfk_2` FOREIGN KEY (`nro_carga`) REFERENCES `carga_inventario` (`nro_carga`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `carga_productos` */

/*Table structure for table `clientes` */

DROP TABLE IF EXISTS `clientes`;

CREATE TABLE `clientes` (
  `codigo_c` varchar(15) NOT NULL,
  `nombre` varchar(200) DEFAULT NULL,
  `cedula_rif` varchar(15) DEFAULT NULL,
  `direccion` varchar(160) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`codigo_c`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `clientes` */

insert  into `clientes`(`codigo_c`,`nombre`,`cedula_rif`,`direccion`,`telefono`) values ('01','FISCALIA SUPERIOR',NULL,NULL,NULL),('02','FISCALIA 1 DELITO COMUNES',NULL,NULL,NULL),('03','FISCALIA 2 DEFENSA PARA LA MUJER',NULL,NULL,NULL),('04','FISCALIA 3 PARA LA DEFENSA DE LA MUJER',NULL,NULL,NULL),('05','FISCALIA 4 DELITOS COMUNES',NULL,NULL,NULL),('06','FISCALIA 6 DELITOS COMUNES',NULL,NULL,NULL),('07','FISCALIA 8 DELITOS COMUNES  ',NULL,NULL,NULL),('08','FISCALIA 9 DELITOS COMUNES',NULL,NULL,NULL),('09','FISCALIA 10 ROBOS Y HURTOS DE VEHÍCULOS',NULL,NULL,NULL),('10','FISCALIA 11 DELITOS COMUNES',NULL,NULL,NULL),('11','FISCALIA 12 CONTRA LA CORRUPCION',NULL,NULL,NULL),('12','FISCALIA 13 DELITOS COMUNES',NULL,NULL,NULL),('13','FISCALIA 14 DELITOS COMUNES',NULL,NULL,NULL),('14','FISCALIA 17 ROBOS Y HURTOS DE VEHÍCULOS',NULL,NULL,NULL),('15','FISCALIA 22 CONSTITUCIONAL Y CONTENCIOSO ADMINISTRATIVO',NULL,NULL,NULL),('16','FISCALIA 23 CONTRAS LAS DROGAS ',NULL,NULL,NULL),('17','FISCALIA 24 CONTRAS LAS DROGAS ',NULL,NULL,NULL),('18','FISCALIA 26 CONTRA LA CORRUPCIÓN',NULL,NULL,NULL),('19','FISCALIA 29 PROTECCIÓN INTEGRAL DE LA FAMILIA',NULL,NULL,NULL),('20','FISCALIA 30 PROTECCIÓN INTEGRAL DE LA FAMILIA',NULL,NULL,NULL),('21','FISCALIA 31 RESPONSABILIDAD PENAL DEL ADOLESCENTE',NULL,NULL,NULL),('22','FISCALIA 33 PENAL ORDINARIO (MENOR VICTIMA',NULL,NULL,NULL),('23','FISCALIA 34 PROTECCIÓN INTEGRAL DE LA FAMILIA',NULL,NULL,NULL),('24','FISCALIA 35 NACIONAL  DELITOS COMUNES',NULL,NULL,NULL),('25','FISCALIA 35 CONTRA LA CORRUPCIÓN',NULL,NULL,NULL),('26','FISCALIA 48 DELITOS COMUNES',NULL,NULL,NULL),('27','FISCALIA 75 NACIONAL RÉGIMEN PENITENCIADO',NULL,NULL,NULL),('28','FISCALIA 76 PROTECCIÓN DE DERECHOS FUNDAMENTALES',NULL,NULL,NULL),('29','FISCALIA 77 NACIONAL CONTRAS LAS DROGA',NULL,NULL,NULL),('30','BIBLIOTECA',NULL,NULL,NULL),('31','UNIDAD ATENCIÓN MEDICA PRIMARIA',NULL,NULL,NULL),('32','COORDINACIÓN DE GESTIÓN SOCIAL',NULL,NULL,NULL),('33','UNIDAD DE ACCESORIA TÉCNICO CIENTÍFICA',NULL,NULL,NULL),('34','DISTRIBUCIÓN',NULL,NULL,NULL),('35','UNIDAD DEPURACIÓN INMEDIATA  DE CAUSAS',NULL,NULL,NULL),('36','UNIDAD DE ATENCIÓN DE LA VICTIMA',NULL,NULL,NULL);

/*Table structure for table `detalle_factura` */

DROP TABLE IF EXISTS `detalle_factura`;

CREATE TABLE `detalle_factura` (
  `linea` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_producto` varchar(15) NOT NULL,
  `numero` int(11) NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `valor_venta` decimal(10,2) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `iva` decimal(10,2) DEFAULT NULL,
  `total_iva` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`linea`),
  KEY `numero` (`numero`),
  KEY `codigo_producto` (`codigo_producto`),
  CONSTRAINT `detalle_factura_ibfk_1` FOREIGN KEY (`numero`) REFERENCES `factura` (`numero`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detalle_factura_ibfk_2` FOREIGN KEY (`codigo_producto`) REFERENCES `productos` (`codigo_producto`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `detalle_factura` */

/*Table structure for table `detalle_insumo` */

DROP TABLE IF EXISTS `detalle_insumo`;

CREATE TABLE `detalle_insumo` (
  `linea` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_producto` varchar(15) NOT NULL,
  `codigo_insumo` int(11) NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `iva` decimal(10,2) DEFAULT NULL,
  `total_iva` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`linea`),
  KEY `codigo_insumo` (`codigo_insumo`),
  KEY `codigo_producto` (`codigo_producto`),
  CONSTRAINT `detalle_insumo_ibfk_1` FOREIGN KEY (`codigo_insumo`) REFERENCES `insumos` (`codigo_insumo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detalle_insumo_ibfk_2` FOREIGN KEY (`codigo_producto`) REFERENCES `productos` (`codigo_producto`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `detalle_insumo` */

/*Table structure for table `factura` */

DROP TABLE IF EXISTS `factura`;

CREATE TABLE `factura` (
  `numero` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_c` varchar(15) NOT NULL,
  `fecha` date DEFAULT NULL,
  `temporal` char(1) DEFAULT NULL,
  PRIMARY KEY (`numero`),
  KEY `codigo_c` (`codigo_c`),
  CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`codigo_c`) REFERENCES `clientes` (`codigo_c`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `factura` */

/*Table structure for table `historico_precios` */

DROP TABLE IF EXISTS `historico_precios`;

CREATE TABLE `historico_precios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_producto` varchar(15) NOT NULL,
  `precio_anterior` decimal(10,2) DEFAULT NULL,
  `precio_nuevo` decimal(10,2) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `codigo_producto` (`codigo_producto`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `historico_precios` */

/*Table structure for table `insumos` */

DROP TABLE IF EXISTS `insumos`;

CREATE TABLE `insumos` (
  `codigo_insumo` int(11) NOT NULL AUTO_INCREMENT,
  `nro_factura_prov` varchar(15) DEFAULT NULL,
  `codigo_prov` varchar(15) NOT NULL,
  `observaciones` text,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`codigo_insumo`),
  KEY `codigo_prov` (`codigo_prov`),
  CONSTRAINT `insumos_ibfk_1` FOREIGN KEY (`codigo_prov`) REFERENCES `proveedores` (`codigo_prov`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `insumos` */

/*Table structure for table `iva` */

DROP TABLE IF EXISTS `iva`;

CREATE TABLE `iva` (
  `valor` decimal(10,2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `iva` */

insert  into `iva`(`valor`) values ('12.00');

/*Table structure for table `productos` */

DROP TABLE IF EXISTS `productos`;

CREATE TABLE `productos` (
  `codigo_producto` varchar(15) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `existencia` bigint(20) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `foto` longblob,
  `exento` tinyint(1) DEFAULT NULL,
  `unidad` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`codigo_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `productos` */

insert  into `productos`(`codigo_producto`,`descripcion`,`existencia`,`precio`,`foto`,`exento`,`unidad`) values ('1120110','PAPEL CARBON T/ CARTA',0,'0.00',NULL,0,'CARPETA'),('1120120','PAPEL CARBON T/OFICIO',0,'0.00',NULL,0,'CARPETA'),('1130110','BLOCK DE ANALISIS 3 COLUMNAS',0,'0.00',NULL,0,'UNIDAD'),('1130125','BLOCK DE ANALISIS 8 COLUMNAS',0,'0.00',NULL,0,'UNIDAD'),('1130145','BLOCK DE ANALISIS 16 COLUMNAS',0,'0.00',NULL,0,'UNIDAD'),('1130150','BLOCK DE ANALISIS 18 COLUMNAS',0,'0.00',NULL,0,'UNIDAD'),('1140410','BLOCK RAYADO T/ CARTA (80F)',0,'0.00',NULL,0,'UNIDAD'),('1140420','BLOCK RAYADO T/ CARTA (40F)',0,'0.00',NULL,0,'UNIDAD'),('1140510','POST- IT- PEQUENA 653',0,'0.00',NULL,0,'UNIDAD'),('1140520','POST- IT- MEDIANA  654',0,'0.00',NULL,0,'UNIDAD'),('1140530','POST- IT- GRANDE 657',0,'0.00',NULL,0,'UNIDAD'),('1150110','LIBRO DE ACTAS 200 FOLIOS',0,'0.00',NULL,0,'UNIDAD '),('1150120','LIBRO DE ACTAS 400 FOLIOS',0,'0.00',NULL,0,'UNIDAD '),('1150130','LIBRO DE ACTAS 500 FOLIOS',0,'0.00',NULL,0,'UNIDAD '),('1150210','LIBRO DE CONOCIMIENTO',0,'0.00',NULL,0,'CAJA '),('1150820','LIBRETA INDICE GRANDE P/ TELEFONO',0,'0.00',NULL,0,'UNIDAD '),('1210120','LAPIZ GRAFITO Nª2',0,'0.00',NULL,0,'UNIDAD '),('1210130','LAPIZ ADHESIVO',0,'0.00',NULL,0,'CAJA '),('1210210','PORTA LAPIZ',0,'0.00',NULL,0,'UNIDAD'),('1220110','MARCADOR P/ PIZARR.ACRIL COLORES/VAR',0,'0.00',NULL,0,'CAJA '),('1220210','MARCADOR PTA ULTRAFINA COLORES /VAR',0,'0.00',NULL,0,'UNIDAD '),('1220220','MARCADOR PTA FINA COLORES /VAR',0,'0.00',NULL,0,'UNIDAD '),('1220230','MARCADOR PTA GRESA  COLORES /VAR',0,'0.00',NULL,0,'CAJA '),('1230110','BOLIGRAFO (COLORES VARIOS)',0,'0.00',NULL,0,'UNIDAD'),('1240110','RESALTADOR COLORES VAR',0,'0.00',NULL,0,'CAJA'),('1310110','SOBRE MANILA  T/ EXTRA RADIOGRAFIA',0,'0.00',NULL,0,'UNIDAD'),('1310120','SOBRE MANILA  T/ EXTRA RADIOGRAFIA',0,'0.00',NULL,0,'UNIDAD'),('1310220','SOBRE BLANCO T/ OFICIO ',0,'0.00',NULL,0,'UNIDAD'),('1310230','SOBRE MANILA 1/2 T/ OFICIO',0,'0.00',NULL,0,'UNIDAD'),('1310310','SOBRE MANILA TIPO CARTA',0,'0.00',NULL,0,'UNIDAD'),('1310320','SOBRE MANILA T/ OFICIO',0,'0.00',NULL,0,'UNIDAD'),('1310330','SOBRE MANILA  T/ EXTRA OFICIO',0,'0.00',NULL,0,'UNIDAD'),('1310340','SOBRE MANILA T/ TELEGRAMA',0,'0.00',NULL,0,'UNIDAD'),('1310410','SOBRE TIMBRADOS C/ VENTANILLA',0,'0.00',NULL,0,'CAJA'),('1310420','SOBRE TIMBRADOS S/ VENTANILLA',0,'0.00',NULL,0,'CAJA'),('1310430','SOBRE BLANCO CON VENTANILLAS',0,'0.00',NULL,0,'UNIDAD'),('1410110','CLIPS Nª1',0,'0.00',NULL,0,'CAJA '),('1410120','CLIPS MARIPOSA Nª 1',0,'0.00',NULL,0,'CAJA '),('1410130','CLIPS MARIPOSA Nª 2',0,'0.00',NULL,0,'CAJA '),('1410140','PORTA CLIPS',0,'0.00',NULL,0,'UNIDAD'),('1410210','SACAGRAPAS',0,'0.00',NULL,0,'UNIDAD'),('1410220','GRAPAS CORRUGADAS Nª2',0,'0.00',NULL,0,'CAJA '),('1410230','GRAPAS LISAS',0,'0.00',NULL,0,'CAJA '),('1410310','ENGRAPADORA TIPO ALICATE',0,'0.00',NULL,0,'UNIDAD '),('1510110','ROLLO P/ SUMADORA 2 1/4',0,'0.00',NULL,0,'UNIDAD'),('1510120','ROLLO P/ SUMADORA 2 3/4',0,'0.00',NULL,0,'UNIDAD'),('1520310','SELLO FECHADOR',0,'0.00',NULL,0,'UNIDAD'),('1530110','BANDAS DE GOMAS (LIMAS)',0,'0.00',NULL,0,'PAQUETE '),('1530210','PAPELERAS',0,'0.00',NULL,0,'UNIDAD'),('1540110','PERFORADORA PEQ.',0,'0.00',NULL,0,'UNIDAD'),('1540120','PERFORADORA GRANDE',0,'0.00',NULL,0,'UNIDAD'),('1560110','BANDEJAS ACRILICAS 3 TRAMOS',0,'0.00',NULL,0,'UNIDAD'),('1560210','TIJERAS',0,'0.00',NULL,0,'UNIDAD'),('1560410','GOMA DE BORRAR ',0,'0.00',NULL,0,'UNIDAD '),('1560510','REGLA PLASTIFICADA DE 30CMS',0,'0.00',NULL,0,'UNIDAD'),('1560710','APLICADOR DE TINTAS P/ ALMUHADILLAS',0,'0.00',NULL,0,'UNIDAD'),('1560720','ALMUHADILLAS P/SELLOS',0,'0.00',NULL,0,'UNIDAD'),('1560721','TINTA AZUL GOTERO P/ SELLOS',0,'0.00',NULL,0,'UNIDAD'),('1560830','DISOLVENTE P/ CORRECTOR LIQUIDO',0,'0.00',NULL,0,'UNIDAD '),('1560840','CORRECTOR  LIQUIDO TIPO LAPIZ',0,'0.00',NULL,0,'UNIDAD '),('1560920','CINTA P/ MAQUINA CALCULADORA',0,'0.00',NULL,0,'UNIDAD'),('1561010','PAPEL P/ FAX 30MTS',0,'0.00',NULL,0,'UNIDAD'),('1561020','PAPEL P/ FAX 50MTS',0,'0.00',NULL,0,'UNIDAD'),('1561040','PELICULA P/ FAX MODELO UX-370/470 M/SHARP',0,'0.00',NULL,0,'UNIDAD'),('1561042','PELICULA P/ FAX PANASONIC KX-FHD351',0,'0.00',NULL,0,'UNIDAD'),('1561043','PELICULA P/ FAX BROTHER 575 PC402RF',0,'0.00',NULL,0,'UNIDAD'),('1561110','CUENTA FACIL',0,'0.00',NULL,0,'UNIDAD '),('1561210','CINTA PLASTICA Nª 3436',0,'0.00',NULL,0,'UNIDAD '),('1561220','DISPENSADOR CINTA Nª 19X33',0,'0.00',NULL,0,'UNIDAD '),('1561230','CINTA PLASTICA Nª 3472',0,'0.00',NULL,0,'UNIDAD '),('1561240','DISPENSADOR CINTA Nª 19X66',0,'0.00',NULL,0,'UNIDAD '),('2210110','MARGARITA P/ MAQ. CANON S-200',0,'0.00',NULL,0,'UNIDAD '),('2210210','MARGARITA P/ MAQ. OLIV ET2500-MD2250',0,'0.00',NULL,0,'UNIDAD '),('2210320','MARGARITA P/ MAQ. OLIMPIA ES-100',0,'0.00',NULL,0,'UNIDAD '),('2210510','MARGARITA P/ MAQ. PANASONIC KX508',0,'0.00',NULL,0,'UNIDAD '),('2210610','MARGARITA P/ MAQ. BROTHER AX 110',0,'0.00',NULL,0,'UNIDAD '),('2210710','MARGARITA P/ MAQ. XEROX MEMO WRITE',0,'0.00',NULL,0,'UNIDAD '),('2210730','MARGARITA P/ MAQ. XEROX 6015',0,'0.00',NULL,0,'UNIDAD '),('2210810','MARGARITA P/ MAQ. FACIL T-320 MN',0,'0.00',NULL,0,'UNIDAD '),('2210920','MARGARITA P/ MAQ. ERIKA 6006',0,'0.00',NULL,0,'UNIDAD '),('2210940','MARGARITA P/ MAQ. OLIVETTI DORA 603',0,'0.00',NULL,0,'UNIDAD '),('2241010','CINTA P/ MAQ. DE ESCRIBIR IBM ESFERA',0,'0.00',NULL,0,'UNIDAD '),('2241110','CINTA P/ MAQUINA ESC PANASONIC KX-508',0,'0.00',NULL,0,'UNIDAD'),('2310110','CORRECTOR P/MAQ. ESC. PANASONIC KX-508',0,'0.00',NULL,0,'CAJA '),('2310210','CORRECTOR P/MAQ. ESC. OLIVETTY E.T.2500',0,'0.00',NULL,0,'CAJA '),('2310310','CORRECTOR P/MAQ. ESC.  OLIMPIA CAMPACT',0,'0.00',NULL,0,'CAJA '),('2310410','CORRECTOR P/MAQ. ESC.  XEROX 6015',0,'0.00',NULL,0,'UNIDAD '),('2310420','CORRECTOR P/MAQ. ESC.  ERIKA 6006',0,'0.00',NULL,0,'CAJA '),('2310510','CORRECTOR P/MAQ. ESC.  CANON S-200',0,'0.00',NULL,0,'CAJA '),('2310520','CORRECTOR P/MAQ. ESC. T.A SE-500',0,'0.00',NULL,0,'CAJA '),('2310530','CORRECTOR P/MAQ. ESC. FACIT T-320',0,'0.00',NULL,0,'CAJA '),('2410110','CINTA P/ MAQ. DE ESCRIBIR T.A SE-310-500',0,'0.00',NULL,0,'UNIDAD '),('2410210','CINTA P/ MAQUINA ESC CANON S-200',0,'0.00',NULL,0,'UNIDAD'),('2410310','CINTA P/ MAQ. DE ESCRIBIR OLIMPIA MASTERTYPE',0,'0.00',NULL,0,'UNIDAD '),('2410320','CINTA P/ MAQ. DE ESCRIBIR OLIMPIA ES 100',0,'0.00',NULL,0,'UNIDAD '),('2410410','CINTA P/ MAQ. DE ESCRIBIR FACIT T-320 NN',0,'0.00',NULL,0,'UNIDAD '),('2410510','CINTA P/ MAQ. DE ESCRIBIR OLIVETTY ET-2500',0,'0.00',NULL,0,'UNIDAD '),('2410610','CINTA P/ MAQ. DE ESCRIBIR XEROX 6015',0,'0.00',NULL,0,'UNIDAD '),('2410620','CINTA P/ MAQ. DE ESCRIBIR XEROX MEMOWRITER',0,'0.00',NULL,0,'UNIDAD '),('2410810','CINTA P/ MAQUINA ESC BROTHER AX 110',0,'0.00',NULL,0,'UNIDAD'),('2410910','CINTA P/ MAQ. DE ESCRIBIR ERIKA 6006',0,'0.00',NULL,0,'UNIDAD '),('3150120','PAPEL FORM. CONT 9 1-2X5 1/2 2P',0,'0.00',NULL,0,'CAJA'),('3150130','PAPEL FORM. CONT 9 1-2X5 1/2 3P',0,'0.00',NULL,0,'CAJA'),('3150310','PAPEL FORM. CONT 14 7-8X11 1P',0,'0.00',NULL,0,'CAJA'),('3150320','PAPEL FORM. CONT  14 7-8X11 2P',0,'0.00',NULL,0,'CAJA'),('3150330','PAPEL FORM. CONT 14 7-8X11 3P',0,'0.00',NULL,0,'CAJA'),('3220120','DISKETTE 3 1/2 ALTA DENSIDAD',0,'0.00',NULL,0,'CAJA '),('3220320','PORTA DISKETTE 5 1/4',0,'0.00',NULL,0,'UNIDAD'),('3310310','CINTA P/ IMPRESORA EPSON LX -300',0,'0.00',NULL,0,'UNIDAD'),('3310330','CINTA P/ IMPRESORA EPSON DFX 8000-50',0,'0.00',NULL,0,'UNIDAD'),('3310610','CINTA P/ IMPRESORA PANASONIC KXP2624',0,'0.00',NULL,0,'UNIDAD'),('3320110','TINTA P/ IMP. CANON BJI-642 NEGRO',0,'0.00',NULL,0,'UNIDAD'),('3320210','TINTA P/IMP. CANON BJI- 800-643',0,'0.00',NULL,0,'UNIDAD'),('3320340','TINTA P/ FAX OLIVETTI OFX 1000 KIT',0,'0.00',NULL,0,'UNIDAD'),('3330010','TONER P/ FOTOCOPIADORA  RICOH AFICIO 2510',0,'0.00',NULL,0,'UNIDAD'),('3330100','TONER HP-Q5942A LASER. 4250/4350',0,'0.00',NULL,0,'UNIDAD'),('3330120','TONER P/ FOTOCOPIADORA XEROX MOD. 5614',0,'0.00',NULL,0,'UNIDAD'),('3330130','MODULO P/ FOTOCOPIADORA XEROX  MOD.5614',0,'0.00',NULL,0,'UNIDAD '),('3330150','TONERP/ IMPR. HP 2200 C 4096A ORIGINAL',0,'0.00',NULL,0,'UNIDAD'),('3330333','TONER KIOCERA TK-332',0,'0.00',NULL,0,'UNIDAD'),('3330460','TONER XEROX MOD. 214/212',0,'0.00',NULL,0,'UNIDAD'),('3330999','TONER P/ FOTOC. CANON IMAGE RUNNER 5070',0,'0.00',NULL,0,'UNIDAD'),('4110110','CARPETA DE MANILA T/ CARTA',0,'0.00',NULL,0,'CAJA '),('4110120','CARPETA DE MANILA T/ OFICIO',0,'0.00',NULL,0,'CAJA '),('4110220','CARPETAS DE FIBRA T/ OFICIO',0,'0.00',NULL,0,'CAJA '),('4120110','CARPETAS COLGANTES 220',0,'0.00',NULL,0,'CAJA '),('4210240','ETIQUETA RECTANGULARES GRANDES',0,'0.00',NULL,0,'SOBRE '),('4210250','ETIQUETA BORDE BLANCO P/ CARPETA',0,'0.00',NULL,0,'SOBRE '),('4210310','OREJETA PLASTICAS P/ CARPETA COLGANTE',0,'0.00',NULL,0,'CAJA '),('4220110','ETIQUETA ADHESIVAS P/ CARPETA',0,'0.00',NULL,0,'SOBRE '),('4220210','ETIQUETA AUTOAD. EN PAPEL LITH',0,'0.00',NULL,0,'SOBRE '),('4310110','ACODEZ PLASTICO (CRISTAL DEX)',0,'0.00',NULL,0,'CAJA'),('4310310','ARCHIVADOR ARCORDEON T/ OFICIO',0,'0.00',NULL,0,'UNIDAD'),('4310610','CARPETA ESPRESS T/ SONEKE',0,'0.00',NULL,0,'UNIDAD'),('4420210','GANCHOS P/CARPETAS',0,'0.00',NULL,0,'CAJA '),('5110001','CARTUCHO NEGRO P/ IMPRESORA 2800',0,'0.00',NULL,0,'UNIDAD'),('5110002','CARTURCHO CYAN P/ IMPRESORA 2800',0,'0.00',NULL,0,'UNIDAD'),('5110003','CARTURCHO COLOR YELLOW P/ IMPRESORA 2800',0,'0.00',NULL,0,'UNIDAD'),('5110004','CARTURCHO COLOR MANGENTA P/ IMPRESORA 2800',0,'0.00',NULL,0,'UNIDAD'),('5110005','HP PRINTHEAD BLACK BUSINES INKJET 280',0,'0.00',NULL,0,'UNIDAD '),('5110006','HP PRINTHEAD CYAN  BUSINES INKJET 280',0,'0.00',NULL,0,'UNIDAD '),('5110007','HP PRINTHEAD  MAGENTA BUSINES INKJET 280',0,'0.00',NULL,0,'UNIDAD '),('5110008','HP PRINTHEAD AMARILLO BUSINES INKJET 2800',0,'0.00',NULL,0,'UNIDAD '),('5110040','CARTUCHO DE TINTA HP DESJET NEGRO IMP.3745',0,'0.00',NULL,0,'UNIDAD'),('5110110','TONER CANON GPR10 IR 1310/1670',0,'0.00',NULL,0,'UNIDAD'),('5110400','CARTUCHO P/ IMPRESORA DESKJET 5550 NEGRO C-6656A',0,'0.00',NULL,0,'UNIDAD'),('5110410','CARTUCHO P/ IMPRESORA DESKJET 5550 A COLOR',0,'0.00',NULL,0,'UNIDAD'),('5110420','CARTUCHO DE TINTA HP DESJET COLOR IMP.3745',0,'0.00',NULL,0,'UNIDAD'),('5110430','CARTUCHO DE PELICULA P/ FAX PANASONIC KXFA-55',0,'0.00',NULL,0,'UNIDAD'),('5110440','CARTUCHO P/ IMPRESORA HP   DESKJET 930 C NEGRO MOD 51645A',0,'0.00',NULL,0,'UNIDAD'),('5110460','CARTUCHO P/ IMPRESORA 2000C 4843A MANGETA',0,'0.00',NULL,0,'UNIDAD'),('5110470','CARTUCHO P/ IMPRESORA HP 2000 C 4844A NEGRO',0,'0.00',NULL,0,'UNIDAD'),('5110480','CARTUCHO P/ IMPRESORA 930C 6578D TRICOLOR',0,'0.00',NULL,0,'UNIDAD'),('5110500','TONER P/ FOTOC. CANON IR330S ORIGNAL',0,'0.00',NULL,0,'CAJA'),('5110510','TONER P/ FOTOC. DELCOP DR9020',0,'0.00',NULL,0,'UNIDAD'),('5110540','CARTUCHO DE PELICULA P/ FAX PANASONIC KXFA-65',0,'0.00',NULL,0,'UNIDAD'),('5110550','CARTUCHO P/ IMPRESORA HP 51640 AZUL DESKJET 1220',0,'0.00',NULL,0,'UNIDAD'),('5110560','CARTUCHO P/ IMPRESORA HP 51640 MANGETA  DESKJET 1220',0,'0.00',NULL,0,'UNIDAD'),('5110570','CARTUCHO P/ IMPRESORA HP 51640 AMARILLO DESKJET 1220',0,'0.00',NULL,0,'UNIDAD'),('5110900','CARTUCHO HP C4844 (NEGRO) P/ IMPRESORA 2300',0,'0.00',NULL,0,'UNIDAD'),('5110901','CARTUCHO HP C4837 (MANGETA) P/ IMPRESORA 2300',0,'0.00',NULL,0,'UNIDAD'),('5110902','CARTUCHO HP C4836 (CYAN) P/ IMPRESORA 2300',0,'0.00',NULL,0,'UNIDAD'),('5110903','CARTUCHO HP C4838 (AMARILLO) P/ IMPRESORA 2300',0,'0.00',NULL,0,'UNIDAD'),('5120000','CARTUCHO NEGRO HP SERIE 5500',0,'0.00',NULL,0,'UNIDAD'),('5120001','CARTUCHO CYAN HP SERIE 5500',0,'0.00',NULL,0,'UNIDAD'),('5120002','CARTURCHO AMARILLO HP SERIE 5500',0,'0.00',NULL,0,'UNIDAD'),('5120003','CARTUCHO MANGETA HP SERIE 5500',0,'0.00',NULL,0,'UNIDAD'),('5120004','CARTUCHO TONER FAX  PANASONIC LASER KX-FL511',0,'0.00',NULL,0,'UNIDAD'),('5120088','TONER P/ IMPR. LEXMARK OPTA 630',0,'0.00',NULL,0,'UNIDAD'),('5120110','TONER P/ FOTOC. CANON 120',0,'0.00',NULL,0,'CAJA'),('5120120','TONER P/ FOTOC. CANON NP -200',0,'0.00',NULL,0,'CAJA'),('5120130','TONER P/ FOTOC. CANON NP 1010-20',0,'0.00',NULL,0,'UNIDAD'),('5120140','TONER P/ FOTOC. CANON 6650 7550 8530',0,'0.00',NULL,0,'UNIDAD'),('5120150','TONER P/ FOTOC. CANON 4050',0,'0.00',NULL,0,'UNIDAD'),('5120170','TONER P/ FOTOC. CANON NPG -11(6012/6412/7130)',0,'0.00',NULL,0,'UNIDAD'),('5120180','TONER P/ FOTOCOPIADORA  NP-7210 (NPG-15)',0,'0.00',NULL,0,'UNIDAD'),('5120210','TONER P/ FOTOC. OLIVETTI C-7147/815/917',0,'0.00',NULL,0,'UNIDAD'),('5120320','TONER P/ FOTOC. XEROX 1012',0,'0.00',NULL,0,'CAJA '),('5120330','TONER P/ FOTOC. OLIVETTI 9910-A',0,'0.00',NULL,0,'UNIDAD'),('5120340','TONER P/ FOTOCOPIADORA  SHARP MOD AL-1000',0,'0.00',NULL,0,'UNIDAD'),('5120350','TONER P/ FOTOCOPIADORA CANON GPR -15',0,'0.00',NULL,0,'UNIDAD'),('5120370','TONER P/ FOTOS. XEROX WORK CENTRE PE-120',0,'0.00',NULL,0,'UNIDAD'),('5120380','TONER P/ FOTOS. XEROX WORK CENTRE PE-16',0,'0.00',NULL,0,'UNIDAD'),('5120390','TONERP/ IMPR. HP LASER JET 2420',0,'0.00',NULL,0,'UNIDAD'),('5120510','TONER P/ FOTOC. MINOLTA EP 3170',0,'0.00',NULL,0,'CAJA '),('5120520','TONER P/ FOTOC. MINOLTA EP-8600',0,'0.00',NULL,0,'UNIDAD'),('5120530','TONER P/ FOTOC. DELCOP DR-9012',0,'0.00',NULL,0,'CAJA'),('5120540','TONER P/ FOTOC. MINOLTA EP 1030',0,'0.00',NULL,0,'CAJA '),('5120550','TONER P/ FOTOC. CANON NP -6030',0,'0.00',NULL,0,'UNIDAD'),('5120610','TINTA P/ IMP. HP DESJET 40026A HP.',0,'0.00',NULL,0,'UNIDAD'),('5120630','TINTA P/ IMP LASER DESJET 5L-6L',0,'0.00',NULL,0,'UNIDAD'),('5120650','TINTA P/ IMP. HP.DESJET 670 COLOR',0,'0.00',NULL,0,'UNIDAD'),('5120660','TINTA P/ IMP. HP.DESJET 670 NEGRO ',0,'0.00',NULL,0,'UNIDAD'),('5120670','TONERP/ IMPR. HP LASER-1106',0,'0.00',NULL,0,'UNIDAD'),('5120700','TONERP/ IMPR. I.B.M.#12',0,'0.00',NULL,0,'UNIDAD'),('5120720','TONER P/ FOTOC. CANON NP 2020/1520',0,'0.00',NULL,0,'CAJA'),('5120730','TONERP/ IMPR. LASER JET 4050N',0,'0.00',NULL,0,'UNIDAD'),('5120740','CARTUCHO P/ IMPRESORA HP DESKJET 810C',0,'0.00',NULL,0,'UNIDAD'),('5120750','CARTUCHO P/ FAX E IMPRESORA CANON BX-3',0,'0.00',NULL,0,'UNIDAD'),('5120760','CARTUCHO P/ IMPRESORA HP 51640 NEGRO DESKJET 1220C',0,'0.00',NULL,0,'UNIDAD'),('5120770','CABEZAL P/ IMPRESORA HP NUMERO 10 2000C',0,'0.00',NULL,0,'UNIDAD'),('5120780','CARTUCHO DE TONER P/ IMPRESORA INFOPRINT 12',0,'0.00',NULL,0,'UNIDAD'),('5120790','CARTUCHO DE TONER P/ IMPRESORA INFOPRINT 21',0,'0.00',NULL,0,'UNIDAD'),('5120830','CARTUCHO DE TINTA P/ IMPRESORA EPSON STYLUS 600 NEGRO',0,'0.00',NULL,0,'UNIDAD'),('5120840','CARTUCHO DE TINTA P/ IMPRESORA CANON BC02 NEGRO',0,'0.00',NULL,0,'UNIDAD'),('5120880','TONER P/ IMPR. LEXMARK OPTA 7612',0,'0.00',NULL,0,'UNIDAD'),('5120890','CARTUCHO DE TINTA P/  FAX  LEXMARK (SAMSUNG)',0,'0.00',NULL,0,'UNIDAD'),('5120900','TONER P/ IMPR. HP LASER JET 1200 C 7115A',0,'0.00',NULL,0,'UNIDAD'),('5120910','TONERP/ IMPR. HP LASER JET 4100 N C 8061',0,'0.00',NULL,0,'UNIDAD'),('5120920','ZIP',0,'0.00',NULL,0,'UNIDAD'),('5120930','CD',0,'0.00',NULL,0,'CAJA '),('5120940','TONER P/ FOTOCOPIADORA XEROX XD100',0,'0.00',NULL,0,'UNIDAD'),('5120941','TONER P/ FOTOCOPIADORA  CANON IR-2000/1600',0,'0.00',NULL,0,'UNIDAD'),('5120950','CD / REGRABABLE VIRGEN',0,'0.00',NULL,0,'CAJA '),('5128888','TONERP/ IMPR. LEXMARK T 644',0,'0.00',NULL,0,'UNIDAD'),('5130110','CARTUCHO NEGRO HP MODELO 96 A 2610',0,'0.00',NULL,0,'UNIDAD'),('5130120','CARTUCHO TRICOLOR HP 97A',0,'0.00',NULL,0,'UNIDAD'),('5160001','TONER RICOH 1140DP/AFCIO',0,'0.00',NULL,0,'UNIDAD'),('5160002','TONER P/ FOTOC. GESTETNER 2913Z',0,'0.00',NULL,0,'UNIDAD'),('5160003','TONER P/ FOTOC. GESTETNER 1502',0,'0.00',NULL,0,'UNIDAD'),('5210100','CARTULINA DE HILO T/ CARTA BLANCA POR 100 HOJAS ',0,'0.00',NULL,0,'REMA '),('5210110','PAPEL BASE 20 T/ CARTA',0,'0.00',NULL,0,'RESMA'),('5210120','PAPEL BASE 20 T/ OFICIO',0,'0.00',NULL,0,'RESMA'),('5210130','PAPEL FOTOCOPIADORA T/EXTRA OFICIO',0,'0.00',NULL,0,'RESMA'),('5310410','GRAPA SEMI-INDUSTRIAL',0,'0.00',NULL,0,'CAJA '),('5310420','GRAPA SEMI-INDUSTRIAL MOD.23/12',0,'0.00',NULL,0,'CAJA '),('5310430','GRAPA SEMI-INDUSTRIAL  MOD.23/17',0,'0.00',NULL,0,'CAJA '),('5310440','GRAPA SEMI-INDUSTRIAL  MOD.23/15',0,'0.00',NULL,0,'CAJA '),('5330210','VASOS PLASTICO PEQ.',0,'0.00',NULL,0,'PAQUETE'),('5330220','VASOS PLASTICO GRANDES',0,'0.00',NULL,0,'PAQUETE'),('7110210','CLORO LIQUIDO',0,'0.00',NULL,0,'GALON'),('7110216','TOALLIN SUAVE BLANCO X12',0,'0.00',NULL,0,'UNIDAD'),('7110315','PASTILLAS DESODORANTE W.C.X.36',0,'0.00',NULL,0,'UNIDAD'),('7210110','BOLSAS PLASTICAS BLANCAS T/ PEQUEÑA',0,'0.00',NULL,0,'UNIDAD'),('7210120','BOLSAS PLASTICAS BLANCAS T/GRANDES',0,'0.00',NULL,0,'UNIDAD'),('7510210','TUALLIN FACIAL DE LUJO',0,'0.00',NULL,0,'CAJA'),('7510212','SERVILLETA DE MESA (120 HOJAS)',0,'0.00',NULL,0,'PAQUETE '),('7510310','PAPEL HIGIENICO (PAQUET 4R)',0,'0.00',NULL,0,'PAQUETE '),('7510410','VASOS CONICOS P/ PARAFINA 50',0,'0.00',NULL,0,'PAQUETE'),('8210120','CASETTE DE VIDEO (VHS)',0,'0.00',NULL,0,'UNIDAD'),('8210210','CASETTE DE HANDY CAN 8M.M.60 MTS',0,'0.00',NULL,0,'UNIDAD'),('8210310','CASETTE P/ GRABADOR 60MN',0,'0.00',NULL,0,'UNIDAD'),('9110110','BOBINA DE PAPEL P/EMVOLVER',0,'0.00',NULL,0,'UNIDAD'),('9110130','TIRRO P/ EMBALAR',0,'0.00',NULL,0,'UNIDAD'),('9110170','CAJA P/ EMBALAJE PEQ',0,'0.00',NULL,0,'UNIDAD');

/*Table structure for table `proveedores` */

DROP TABLE IF EXISTS `proveedores`;

CREATE TABLE `proveedores` (
  `codigo_prov` varchar(15) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `direccion` varchar(160) DEFAULT NULL,
  `rif` varchar(15) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`codigo_prov`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `proveedores` */

insert  into `proveedores`(`codigo_prov`,`nombre`,`direccion`,`rif`,`telefono`) values ('01','Nebabrica','calle 71','J-5698333-5','0261-3333'),('02','Papelerias Ramirez','la limpia','J-5665225-5','0261-555554'),('03','Papeleria Falcon','Calle falcon','J-87546225-3','0261-5488545');

/*Table structure for table `usuarios` */

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `login` varchar(20) NOT NULL,
  `tipo` char(1) DEFAULT NULL,
  `clave` varchar(20) DEFAULT NULL,
  `nombre` varchar(40) NOT NULL,
  PRIMARY KEY (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `usuarios` */

insert  into `usuarios`(`login`,`tipo`,`clave`,`nombre`) values ('administrador','A','123','administrador'),('usuario','U','123','usuario'),('1','A','1','1'),('01','A','1','Jorge Suarez');

/* Trigger structure for table `carga_inventario` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_eliminar_carga_inventario` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_eliminar_carga_inventario` BEFORE DELETE ON `carga_inventario` FOR EACH ROW BEGIN
       delete from carga_productos where nro_carga = old.nro_carga;
    END */$$


DELIMITER ;

/* Trigger structure for table `carga_productos` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_cargar_inventario` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_cargar_inventario` AFTER INSERT ON `carga_productos` FOR EACH ROW BEGIN
    declare vTipo varchar(3);
    
        select tipo into vTipo
          from carga_inventario 
         where nro_carga = new.nro_carga;
           
           
        if vTipo ='C' then  
           update productos a 
              set a.existencia = a.existencia + new.cantidad
            where a.codigo_producto = new.codigo_producto; 
         ELSE
           UPDATE productos a 
              SET a.existencia = a.existencia - new.cantidad
            WHERE a.codigo_producto = new.codigo_producto; 
            
         end if;
    END */$$


DELIMITER ;

/* Trigger structure for table `carga_productos` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_restar_productos` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_restar_productos` AFTER DELETE ON `carga_productos` FOR EACH ROW BEGIN
        
        update productos a 
           set a.existencia = a.existencia - old.cantidad
       where a.codigo_producto = old.codigo_producto; 
    END */$$


DELIMITER ;

/* Trigger structure for table `detalle_factura` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_restar_inventario` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_restar_inventario` AFTER INSERT ON `detalle_factura` FOR EACH ROW begin
    
    declare v_cantidad integer;
    
     select b.existencia - new.cantidad into v_cantidad
                       from productos b
                      where b.codigo_producto = new.codigo_producto;
                      
    if v_cantidad < 0 then
       insert into productos(codigo_producto) values(null); 	
    end if;                   
                                                   
    update productos a 
       set a.existencia = a.existencia - new.cantidad
     where a.codigo_producto = new.codigo_producto;   
          
  
    end */$$


DELIMITER ;

/* Trigger structure for table `detalle_factura` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_actualizar_inventario` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_actualizar_inventario` BEFORE UPDATE ON `detalle_factura` FOR EACH ROW begin
       declare v_cantidad integer;
    
     select b.existencia - new.cantidad + old.cantidad into v_cantidad
                       from productos b
                      where b.codigo_producto = new.codigo_producto;
                      
    if v_cantidad < 0 then
       insert into productos(codigo_producto) values(null); 	
    end if;                   
                                                   
    update productos a 
       set a.existencia = v_cantidad 
     where a.codigo_producto = new.codigo_producto;   
          
 
    end */$$


DELIMITER ;

/* Trigger structure for table `detalle_factura` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_sumar_eliminado` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_sumar_eliminado` AFTER DELETE ON `detalle_factura` FOR EACH ROW begin
       
       update productos a
          set a.existencia = a.existencia + old.cantidad
       where a.codigo_producto = old.codigo_producto;   
    end */$$


DELIMITER ;

/* Trigger structure for table `detalle_insumo` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_incrementar_insumos` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_incrementar_insumos` AFTER INSERT ON `detalle_insumo` FOR EACH ROW BEGIN
       update productos a 
           set a.existencia = a.existencia + new.cantidad
       where a.codigo_producto = new.codigo_producto;    
    END */$$


DELIMITER ;

/* Trigger structure for table `detalle_insumo` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_eliminar_insumos` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_eliminar_insumos` BEFORE DELETE ON `detalle_insumo` FOR EACH ROW BEGIN
       update productos a
          set a.existencia = a.existencia - old.cantidad 
        where a.codigo_producto = old.codigo_producto;   
    END */$$


DELIMITER ;

/* Trigger structure for table `factura` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_eliminar_factura` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_eliminar_factura` BEFORE DELETE ON `factura` FOR EACH ROW BEGIN
       delete from detalle_factura where numero = old.numero;
    END */$$


DELIMITER ;

/* Trigger structure for table `insumos` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_eliminar_insumo_principal` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_eliminar_insumo_principal` BEFORE DELETE ON `insumos` FOR EACH ROW BEGIN
    
       delete 
         from detalle_insumo  
        where codigo_insumo = old.codigo_insumo;    
    END */$$


DELIMITER ;

/* Trigger structure for table `productos` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_actualizar_precios` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'127.0.0.1' */ /*!50003 TRIGGER `trg_actualizar_precios` AFTER UPDATE ON `productos` FOR EACH ROW BEGIN
       if new.precio <> old.precio then
          insert into historico_precios(codigo_producto, precio_nuevo, precio_anterior, fecha, hora)
               values (new.codigo_producto, new.precio, old.precio, current_date, current_time);
       end if;
    END */$$


DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
